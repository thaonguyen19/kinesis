# Android_BluetoothScanner
Start up Bluetooth, display currently paired devices and scan for new Bluetooth devices

This is the source code for a tutorial project on how to start up Bluetooth, display a list of the already paired
Bluetooth devices, and how to scan for new Bluetooth devices in range.

The tutorial can be found here:
http://toomanytutorials.blogspot.com/2015/03/scanning-for-bluetooth-devices-in.html

Eduardo
